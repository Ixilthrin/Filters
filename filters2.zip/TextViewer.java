package filters;

import javax.swing.*;

public class TextViewer extends JEditorPane {
}
