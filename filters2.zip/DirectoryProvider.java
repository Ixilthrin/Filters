package filters;

public interface DirectoryProvider {
    String getDirectory();
}
